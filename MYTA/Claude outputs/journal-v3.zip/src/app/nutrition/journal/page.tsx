'use client'

import { useEffect, useState, useRef, useCallback } from 'react'
import { createClient } from '@/lib/supabase/client'
import { format } from 'date-fns'
import { fr } from 'date-fns/locale'
import {
  Flame, Search, X, Trash2, Loader2, Scale, BarChart3, Camera, Pencil, Plus, Wheat, Pill, Microscope, Cigarette, Trophy, Heart, AlertTriangle, Check, Circle,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { getSmokingWatyMessage } from '@/lib/gamification'
import { todayISO, round1 } from '@/lib/utils'
import { searchFoods, type FoodItem } from '@/lib/foods-db'
import { Waty, getWatyMessage } from '@/components/ui/Waty'
import OnboardingCoach from '@/components/ui/OnboardingCoach'
import { useOnboarding } from '@/lib/onboarding'
import { useRouter } from 'next/navigation'
import { VoiceMeal, type DetectedFood } from '@/components/nutrition/VoiceMeal'
import {
  calcInflamScore, hasGluten, classifyInflam,
  inflamGaugePct, inflamAdvice, calcMicros,
} from '@/lib/nutrition-analysis'
import {
  SUPPLEMENTS, searchSupplements, calcSupplementMicros, MICRO_RDA,
  type Supplement, type MicroKey,
} from '@/lib/supplements-db'
import { getActiveProfile } from '@/lib/active-profile'
import type { JournalEntry, WeightLog, Profile } from '@/types'
import { MytaIcon } from '@/components/ui/MytaIcon'
import { MytaIllustration } from '@/components/ui/MytaIllustration'

interface DayMacros { cal: number; prot: number; carb: number; fat: number }

// Mapping nom micro CIQUAL → clé supplément pour fusion des barres
const MICRO_NAME_TO_SUPP_KEY: Record<string, MicroKey> = {
  'Vit. D':    'vitD',
  'Vit. C':    'vitC',
  'Vit. B12':  'vitB12',
  'Fer':       'fer',
  'Calcium':   'calcium',
  'Magnésium': 'magnesium',
  'Zinc':      'zinc',
  'Oméga-3':   'omega3',
}

// ─── Helpers date ──────────────────────────────────────────────────────────
function addDays(str: string, n: number): string {
  const d = new Date(str + 'T12:00:00')
  d.setDate(d.getDate() + n)
  return d.toISOString().split('T')[0]
}

function formatDateFR(str: string): string {
  const d = new Date(str + 'T12:00:00')
  return format(d, 'EEEE d MMMM yyyy', { locale: fr })
}



// ─── Modal détail nutriment ────────────────────────────────────────────────
interface NutrientEntry { food_name: string; value: number; unit: string }

function NutrientDetailModal({ title, color, entries, onClose }: {
  title: string; color: string; entries: NutrientEntry[]; onClose: () => void
}) {
  const total = entries.reduce((s, e) => s + e.value, 0)
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/50"
      onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl max-h-[80vh] overflow-y-auto">
        <div className="sticky top-0 bg-white px-5 py-4 border-b border-zinc-100 flex items-center justify-between">
          <h3 className="font-extrabold text-zinc-900">{title}</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-xl bg-zinc-100 flex items-center justify-center text-zinc-400">
            <X size={14} />
          </button>
        </div>
        <div className="p-5 flex flex-col gap-3">
          {entries.length === 0 ? (
            <p className="text-sm text-zinc-400 text-center py-4">Aucun aliment contributeur détecté.</p>
          ) : entries.map((e, i) => {
            const pct = total > 0 ? Math.round((e.value / total) * 100) : 0
            return (
              <div key={i} className="flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-zinc-900 truncate">{e.food_name}</p>
                  <div className="h-1.5 bg-zinc-100 rounded-full mt-1 overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${pct}%`, background: color }} />
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-sm font-bold" style={{ color }}>{round1(e.value)} {e.unit}</p>
                  <p className="text-[10px] text-zinc-400">{pct}%</p>
                </div>
              </div>
            )
          })}
          <p className="text-xs text-zinc-400 text-center pt-2 border-t border-zinc-100">
            Total : <span className="font-bold">{round1(total)} {entries[0]?.unit ?? ''}</span>
          </p>
        </div>
      </div>
    </div>
  )
}

// ─── Composant modal ajout aliment ────────────────────────────────────────
function AddFoodModal({ food, onConfirm, onClose }: {
  food: FoodItem
  onConfirm: (qty: number) => void
  onClose: () => void
}) {
  const [qty, setQty] = useState(100)
  const r = qty / 100
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl">
        <h3 className="font-bold text-zinc-900 mb-1 inline-flex items-center gap-1.5"><Plus size={15} /> Ajouter</h3>
        <p className="text-sm text-nutri-dark font-semibold mb-4 truncate">{food.name}</p>

        <div className="grid grid-cols-2 gap-2 mb-4">
          {[
            { val: Math.round(food.cal * r), lbl: 'kcal', color: 'text-orange-500' },
            { val: round1(food.prot * r),    lbl: 'Prot.', color: 'text-blue-500' },
            { val: round1(food.carb * r),    lbl: 'Gluc.', color: 'text-yellow-500' },
            { val: round1(food.fat * r),     lbl: 'Lip.',  color: 'text-purple-500' },
          ].map(({ val, lbl, color }) => (
            <div key={lbl} className="text-center bg-zinc-50 rounded-xl p-2">
              <div className={`text-base font-black ${color}`}>{val}</div>
              <div className="text-xs text-zinc-400 uppercase">{lbl}</div>
            </div>
          ))}
        </div>

        <div className="flex items-center gap-3 mb-4">
          <input
            type="number" min={1} max={5000} value={qty}
            onChange={e => setQty(Number(e.target.value))}
            className="input flex-1 text-center font-mono text-lg font-bold"
            autoFocus
          />
          <span className="text-sm text-zinc-400 font-semibold">grammes</span>
        </div>

        <div className="flex gap-2">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-zinc-200 text-sm font-medium text-zinc-600 hover:bg-zinc-50">Annuler</button>
          <button onClick={() => onConfirm(qty)} className="flex-1 py-2.5 rounded-xl bg-nutri text-white text-sm font-bold hover:bg-nutri-dark">Ajouter</button>
        </div>
      </div>
    </div>
  )
}

// ─── Composant modal modification quantité ─────────────────────────────────
function EditQtyModal({ entry, onConfirm, onClose }: {
  entry: JournalEntry
  onConfirm: (qty: number) => void
  onClose: () => void
}) {
  const oldQty = Number(entry.quantity) || 100
  const [qty, setQty] = useState(oldQty)
  const r = qty / oldQty
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl">
        <h3 className="font-bold text-zinc-900 mb-1 inline-flex items-center gap-1.5"><Pencil size={14} /> Modifier la quantité</h3>
        <p className="text-sm text-nutri-dark font-semibold mb-4 truncate">{entry.food_name}</p>

        <div className="grid grid-cols-2 gap-2 mb-4">
          {[
            { val: Math.round(Number(entry.cal) * r), lbl: 'kcal', color: 'text-orange-500' },
            { val: round1(Number(entry.prot) * r),    lbl: 'Prot.', color: 'text-blue-500' },
            { val: round1(Number(entry.carb) * r),    lbl: 'Gluc.', color: 'text-yellow-500' },
            { val: round1(Number(entry.fat) * r),     lbl: 'Lip.',  color: 'text-purple-500' },
          ].map(({ val, lbl, color }) => (
            <div key={lbl} className="text-center bg-zinc-50 rounded-xl p-2">
              <div className={`text-base font-black ${color}`}>{val}</div>
              <div className="text-xs text-zinc-400 uppercase">{lbl}</div>
            </div>
          ))}
        </div>

        <div className="flex items-center gap-3 mb-4">
          <input
            type="number" min={1} max={5000} value={qty}
            onChange={e => setQty(Number(e.target.value))}
            className="input flex-1 text-center font-mono text-lg font-bold"
            autoFocus
          />
          <span className="text-sm text-zinc-400 font-semibold">grammes</span>
        </div>

        <div className="flex gap-2">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-zinc-200 text-sm font-medium text-zinc-600 hover:bg-zinc-50">Annuler</button>
          <button onClick={() => qty > 0 && onConfirm(qty)} className="flex-1 py-2.5 rounded-xl bg-nutri text-white text-sm font-bold hover:bg-nutri-dark">Enregistrer</button>
        </div>
      </div>
    </div>
  )
}

// ─── Page principale ───────────────────────────────────────────────────────
export default function JournalPage() {
  const supabase = createClient()
  const router = useRouter()
  const { step: obStep, advance: obAdvance, skip: obSkip } = useOnboarding()

  const [currentDate, setCurrentDate] = useState(todayISO())
  const [entries, setEntries]         = useState<JournalEntry[]>([])
  const [profile, setProfile]         = useState<Profile | null>(null)
  const [weights, setWeights]         = useState<WeightLog[]>([])
  const [recentFoods, setRecentFoods]   = useState<JournalEntry[]>([])
  const [weekCal, setWeekCal]         = useState<Record<string, number>>({})
  const [loading, setLoading]         = useState(true)

  // Recherche
  const [query, setQuery]           = useState('')
  const [results, setResults]       = useState<FoodItem[]>([])
  const [searching, setSearching]   = useState(false)
  const [selectedFood, setSelectedFood] = useState<FoodItem | null>(null)
  const [showVoiceMeal, setShowVoiceMeal] = useState(false)
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Poids
  const [weightInput, setWeightInput] = useState('')
  const [savingWeight, setSavingWeight] = useState(false)

  const [toast, setToast] = useState<{ msg: string; type: 'ok' | 'err' } | null>(null)
  const [nutriModal, setNutriModal] = useState<{ title: string; color: string; entries: NutrientEntry[] } | null>(null)
  const [editingEntry, setEditingEntry] = useState<JournalEntry | null>(null)

  // ── Photo analyse ──────────────────────────────────────────
  const photoInputRef = useRef<HTMLInputElement>(null)
  const [photoAnalyzing, setPhotoAnalyzing]   = useState(false)
  const [photoFoods, setPhotoFoods]           = useState<DetectedFood[] | null>(null)
  const [photoPreview, setPhotoPreview]       = useState<string | null>(null)
  const [photoError, setPhotoError]           = useState('')

  // ── Compléments ────────────────────────────────────────────
  const [showSupplPanel, setShowSupplPanel]   = useState(false)
  const [supplQuery, setSupplQuery]           = useState('')
  const [supplResults, setSupplResults]       = useState<Supplement[]>([])
  const [addingSuppl, setAddingSuppl]         = useState(false)

  // ── Tabac ──────────────────────────────────────────────────
  const [smokingCount, setSmokingCount]       = useState(0)
  const [smokingYesterday, setSmokingYesterday] = useState<number | null>(null)
  const [smokingStreak, setSmokingStreak]     = useState(0)
  const [savingSmoke, setSavingSmoke]         = useState(false)

  // Objectifs calculés depuis profil
  const goals = useCallback((): DayMacros => {
    if (!profile?.weight_kg || !profile?.height_cm || !profile?.birth_date) {
      return { cal: 2000, prot: 120, carb: 225, fat: 65 }
    }
    const age = new Date().getFullYear() - new Date(profile.birth_date).getFullYear()
    const bmr = profile.goal === 'femme'
      ? 10 * profile.weight_kg + 6.25 * profile.height_cm - 5 * age - 161
      : 10 * profile.weight_kg + 6.25 * profile.height_cm - 5 * age + 5
    const tdee = Math.round(bmr * 1.55)
    const cal = profile.calorie_target ?? tdee
    return {
      cal,
      prot: profile.prot_target ?? Math.round(profile.weight_kg * 1.6),
      carb: profile.carb_target ?? Math.round(cal * 0.40 / 4),
      fat:  profile.fat_target  ?? Math.round(cal * 0.30 / 9),
    }
  }, [profile])

  // Helper : récupérer le token d'auth pour les appels API
  async function getToken(): Promise<string | null> {
    const { data: { session } } = await supabase.auth.getSession()
    return session?.access_token ?? null
  }

  // Charge données initiales
  useEffect(() => { loadAll() }, [])

  // Parcours guidé : dès qu'un premier repas est enregistré (vocal/photo/texte) → étape sport.
  useEffect(() => {
    if (obStep === 'journal' && entries.length > 0) {
      ;(async () => {
        await obAdvance('journal')
        router.push('/sport/session')
      })()
    }
  }, [obStep, entries.length]) // eslint-disable-line react-hooks/exhaustive-deps

  // Recharge journal quand la date change
  useEffect(() => { loadDay(currentDate) }, [currentDate])

  async function loadAll() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    // ── Mode enfant ──────────────────────────────────────────────────────────
    const ap = getActiveProfile()
    if (ap.isChild && ap.childId) {
      const token   = await getToken()
      const headers: Record<string, string> = token ? { Authorization: `Bearer ${token}` } : {}
      const childId = ap.childId

      // Profil enfant → construit un objet Profile-like pour goals()
      const cpRes = await fetch(`/api/family/child?id=${childId}`, { headers })
      if (cpRes.ok) {
        const cp = await cpRes.json()
        if (cp) {
          const isFemale = ['female', 'fille', 'f'].includes((cp.gender ?? '').toLowerCase())
          setProfile({
            id:             childId,
            full_name:      cp.name,
            avatar_url:     null,
            weight_kg:      cp.weight_kg   ?? null,
            height_cm:      cp.height_cm   ?? null,
            birth_date:     cp.birth_date  ?? null,
            goal:           isFemale ? 'femme' : null,
            calorie_target: null,
            prot_target:    null,
            carb_target:    null,
            fat_target:     null,
            created_at:     cp.created_at  ?? new Date().toISOString(),
          } as Profile)
        }
      }

      // Résumé 7 jours
      const days    = Array.from({ length: 7 }, (_, i) => addDays(todayISO(), -i))
      const wkRes   = await fetch(`/api/child-journal?child_id=${childId}&week=${days.join(',')}`, { headers })
      if (wkRes.ok) {
        const rows: any[] = await wkRes.json()
        const map: Record<string, number> = {}
        for (const r of rows) map[r.date] = (map[r.date] ?? 0) + Number(r.cal)
        setWeekCal(map)
      }

      // Aliments récents
      const recRes = await fetch(`/api/child-journal?child_id=${childId}&recent=true`, { headers })
      if (recRes.ok) {
        const recent: any[] = await recRes.json()
        const seen  = new Set<string>()
        const deduped: JournalEntry[] = []
        for (const r of recent) {
          if (!seen.has(r.food_name)) { seen.add(r.food_name); deduped.push(r) }
          if (deduped.length >= 8) break
        }
        setRecentFoods(deduped)
      }

      await loadDay(currentDate)
      setLoading(false)
      return
    }
    // ── Fin mode enfant ──────────────────────────────────────────────────────

    const [{ data: prof }, { data: wts }] = await Promise.all([
      supabase.from('profiles').select('*').eq('id', user.id).single(),
      supabase.from('weight_log').select('*').eq('user_id', user.id).order('date', { ascending: false }).limit(14),
    ])
    setProfile(prof ?? null)
    setWeights(wts ?? [])

    // ── Tabac : charger si objectif activé ─────────────────
    if ((prof as any)?.smoking_goal) {
      const today = todayISO()
      const d = new Date(today + 'T12:00:00'); d.setDate(d.getDate() - 1)
      const yesterday = d.toISOString().split('T')[0]

      const [{ data: todayLog }, { data: yesterdayLog }, { data: smokeLogs }] = await Promise.all([
        supabase.from('smoking_log').select('count').eq('user_id', user.id).eq('log_date', today).single(),
        supabase.from('smoking_log').select('count').eq('user_id', user.id).eq('log_date', yesterday).single(),
        supabase.from('smoking_log').select('count,log_date').eq('user_id', user.id).order('log_date', { ascending: false }).limit(30),
      ])
      setSmokingCount((todayLog as any)?.count ?? 0)
      setSmokingYesterday((yesterdayLog as any)?.count ?? null)

      // Calculer série de jours à 0 cigarettes
      let streak = 0
      for (const log of smokeLogs ?? []) {
        if ((log as any).count === 0) streak++
        else break
      }
      setSmokingStreak(streak)
    }

    // Préparer weekCal (7 jours)
    const days = Array.from({ length: 7 }, (_, i) => addDays(todayISO(), -i))
    const { data: calRows } = await supabase.from('journal_entries')
      .select('date, cal').eq('user_id', user.id).in('date', days)
    const map: Record<string, number> = {}
    for (const r of calRows ?? []) map[r.date] = (map[r.date] ?? 0) + Number(r.cal)
    setWeekCal(map)

    // Charger les 8 aliments les plus récents (derniers 7 jours)
    const { data: recent } = await supabase.from('journal_entries')
      .select('*').eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(30)
    // Dédupliquer par food_name, garder le plus récent de chaque
    const seen = new Set<string>()
    const deduped: JournalEntry[] = []
    for (const r of recent ?? []) {
      if (!seen.has(r.food_name)) { seen.add(r.food_name); deduped.push(r) }
      if (deduped.length >= 8) break
    }
    setRecentFoods(deduped)

    await loadDay(currentDate)
    setLoading(false)
  }

  async function loadDay(date: string) {
    const ap = getActiveProfile()
    if (ap.isChild && ap.childId) {
      const token   = await getToken()
      const headers: Record<string, string> = token ? { Authorization: `Bearer ${token}` } : {}
      const res = await fetch(`/api/child-journal?child_id=${ap.childId}&date=${date}`, { headers })
      if (res.ok) setEntries((await res.json()) as JournalEntry[])
      return
    }
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    const { data } = await supabase.from('journal_entries')
      .select('*').eq('user_id', user.id).eq('date', date).order('created_at')
    setEntries((data as JournalEntry[]) ?? [])
  }

  // Séparer aliments et compléments
  const foodEntries = entries.filter(e => e.food_cat !== 'complément')
  const supplEntries = entries.filter(e => e.food_cat === 'complément')

  // Totaux du jour (hors compléments)
  const totals: DayMacros = foodEntries.reduce((t, e) => ({
    cal:  Math.round(t.cal  + Number(e.cal)),
    prot: round1(t.prot + Number(e.prot)),
    carb: round1(t.carb + Number(e.carb)),
    fat:  round1(t.fat  + Number(e.fat)),
  }), { cal: 0, prot: 0, carb: 0, fat: 0 })

  // ── Compléments ─────────────────────────────────────────────────────────────
  function handleSupplSearch(q: string) {
    setSupplQuery(q)
    if (!q.trim()) { setSupplResults([]); return }
    setSupplResults(searchSupplements(q))
  }

  async function addSupplement(supp: Supplement, qty: number = 1) {
    const ap    = getActiveProfile()
    const token = await getToken()
    const headers: Record<string, string> = { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }
    setAddingSuppl(true)
    const entryBase = {
      date:      currentDate,
      food_id:   'supp-' + supp.id,
      food_name: supp.name,
      food_cat:  'complément',
      quantity:  qty,
      cal: 0, prot: 0, carb: 0, fat: 0,
      image_url: null,
    }

    if (ap.isChild && ap.childId) {
      const res = await fetch('/api/child-journal', {
        method: 'POST', headers,
        body: JSON.stringify({ child_id: ap.childId, ...entryBase }),
      })
      if (res.ok) { await loadDay(currentDate); showToast(`${supp.name} ajouté`, 'ok') }
      else { showToast('Erreur ajout complément', 'err') }
    } else {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { setAddingSuppl(false); return }
      const { error } = await supabase.from('journal_entries').insert({ user_id: user.id, ...entryBase })
      if (!error) { await loadDay(currentDate); showToast(`${supp.name} ajouté`, 'ok') }
      else { showToast('Erreur ajout complément', 'err') }
    }

    setAddingSuppl(false)
    setSupplQuery('')
    setSupplResults([])
  }

  // ── Recherche aliments — base locale instantanée + API serveur en complément
  function handleSearch(q: string) {
    setQuery(q)
    if (searchTimer.current) clearTimeout(searchTimer.current)
    if (q.length < 2) { setResults([]); setSearching(false); return }

    // Phase 1 : résultats locaux instantanés (CIQUAL, tout en FR)
    const local = searchFoods(q, 8)
    setResults(local)

    // Phase 2 : API serveur (USDA + OFF traduit FR) après 600ms
    setSearching(true)
    searchTimer.current = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search-food?q=${encodeURIComponent(q)}`)
        const data = await res.json()
        const remote: FoodItem[] = data.results ?? []
        // Fusion sans doublons
        const seen = new Set(local.map(f => String(f.name).toLowerCase().trim().slice(0, 25)))
        const merged = [
          ...local,
          ...remote.filter(f => !seen.has(String(f.name).toLowerCase().trim().slice(0, 25)))
        ]
        setResults(merged.slice(0, 15))
      } catch {
        // Garde les résultats locaux si l'API échoue
      }
      setSearching(false)
    }, 600)
  }

  async function confirmAdd(qty: number) {
    if (!selectedFood) return
    const ap    = getActiveProfile()
    const token = await getToken()
    const headers: Record<string, string> = { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }
    const ratio = qty / 100
    const entryBase = {
      date:      currentDate,
      food_id:   selectedFood.id,
      food_name: selectedFood.name,
      food_cat:  selectedFood.cat ?? 'produit',
      quantity:  qty,
      cal:       Math.round(selectedFood.cal  * ratio),
      prot:      round1(selectedFood.prot * ratio),
      carb:      round1(selectedFood.carb * ratio),
      fat:       round1(selectedFood.fat  * ratio),
      image_url: selectedFood.image_url ?? null,
    }

    if (ap.isChild && ap.childId) {
      const res = await fetch('/api/child-journal', {
        method: 'POST', headers,
        body: JSON.stringify({ child_id: ap.childId, ...entryBase }),
      })
      if (!res.ok) { showToast('Erreur ajout', 'err'); return }
    } else {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      const { error } = await supabase.from('journal_entries').insert({ user_id: user.id, ...entryBase })
      if (error) { showToast('Erreur ajout', 'err'); return }
    }

    setSelectedFood(null)
    setQuery('')
    setResults([])
    await loadDay(currentDate)
    setWeekCal(prev => ({ ...prev, [currentDate]: (prev[currentDate] ?? 0) + entryBase.cal }))
    showToast(`${selectedFood.name} ajouté`, 'ok')
  }

  async function handleVoiceMealConfirm(foods: DetectedFood[]) {
    const ap    = getActiveProfile()
    const token = await getToken()
    const headers: Record<string, string> = { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }

    const foodEntries = foods.map(f => ({
      date:      currentDate,
      food_id:   null,
      food_name: f.name,
      food_cat:  f.cat ?? 'aliment',
      quantity:  f.quantity,
      cal:       Math.round(f.cal),
      prot:      round1(f.prot),
      carb:      round1(f.carb),
      fat:       round1(f.fat),
      image_url: null,
    }))

    if (ap.isChild && ap.childId) {
      for (const e of foodEntries) {
        const res = await fetch('/api/child-journal', {
          method: 'POST', headers,
          body: JSON.stringify({ child_id: ap.childId, ...e }),
        })
        if (!res.ok) { showToast('Erreur ajout', 'err'); return }
      }
    } else {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      const { error } = await supabase.from('journal_entries').insert(foodEntries.map(e => ({ user_id: user.id, ...e })))
      if (error) { showToast('Erreur ajout', 'err'); return }
    }

    setShowVoiceMeal(false)
    await loadDay(currentDate)
    const totalCal = foodEntries.reduce((s, e) => s + e.cal, 0)
    setWeekCal(prev => ({ ...prev, [currentDate]: (prev[currentDate] ?? 0) + totalCal }))
    showToast(`${foods.length} aliment${foods.length > 1 ? 's' : ''} ajouté${foods.length > 1 ? 's' : ''}`, 'ok')
  }

  async function handlePhotoCapture(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    // Reset pour permettre re-sélection du même fichier
    e.target.value = ''
    setPhotoAnalyzing(true)
    setPhotoError('')
    const preview = URL.createObjectURL(file)
    setPhotoPreview(preview)
    try {
      const { data: { session } } = await supabase.auth.getSession()
      const token = session?.access_token
      const fd = new FormData()
      fd.append('image', file)
      const res = await fetch('/api/analyze-meal-photo', {
        method: 'POST',
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: fd,
      })
      const data = await res.json()
      if (data.foods && data.foods.length > 0) {
        setPhotoFoods(data.foods)
      } else {
        setPhotoError(data.error ?? 'Aucun aliment détecté dans la photo')
        URL.revokeObjectURL(preview)
        setPhotoPreview(null)
      }
    } catch {
      setPhotoError("Erreur lors de l'analyse de la photo")
      URL.revokeObjectURL(preview)
      setPhotoPreview(null)
    }
    setPhotoAnalyzing(false)
  }

  async function updateEntryQty(entry: JournalEntry, newQty: number) {
    const oldQty = Number(entry.quantity) || 100
    const r = newQty / oldQty
    const patch = {
      quantity: newQty,
      cal:  Math.round(Number(entry.cal) * r),
      prot: round1(Number(entry.prot) * r),
      carb: round1(Number(entry.carb) * r),
      fat:  round1(Number(entry.fat) * r),
    }
    const ap = getActiveProfile()
    if (ap.isChild && ap.childId) {
      const token = await getToken()
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      }
      await fetch('/api/child-journal', {
        method: 'PUT', headers,
        body: JSON.stringify({ id: entry.id, child_id: ap.childId, ...patch }),
      })
    } else {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      await supabase.from('journal_entries').update(patch)
        .eq('id', entry.id).eq('user_id', user.id)
    }
    setEditingEntry(null)
    await loadDay(currentDate)
    showToast('Quantité mise à jour', 'ok')
  }

  async function deleteEntry(id: string) {
    const ap = getActiveProfile()
    if (ap.isChild && ap.childId) {
      const token = await getToken()
      const headers: Record<string, string> = token ? { Authorization: `Bearer ${token}` } : {}
      await fetch(`/api/child-journal?id=${id}&child_id=${ap.childId}`, { method: 'DELETE', headers })
    } else {
      await supabase.from('journal_entries').delete().eq('id', id)
    }
    await loadDay(currentDate)
    showToast('Aliment supprimé', 'err')
  }

  async function logWeight() {
    const val = parseFloat(weightInput)
    if (!val || val < 20 || val > 400) { showToast('Poids invalide', 'err'); return }
    setSavingWeight(true)
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { setSavingWeight(false); return }
    await supabase.from('weight_log').delete().eq('user_id', user.id).eq('date', currentDate)
    const { error: insErr } = await supabase.from('weight_log').insert({ user_id: user.id, date: currentDate, weight_kg: val })
    if (insErr) { console.error('[weight_log]', insErr); showToast('Erreur enregistrement poids', 'err'); setSavingWeight(false); return }
    const { data } = await supabase.from('weight_log')
      .select('*').eq('user_id', user.id).order('date', { ascending: false }).limit(14)
    setWeights(data ?? [])
    setWeightInput('')
    setSavingWeight(false)
    showToast(`${val} kg enregistré`, 'ok')
  }

  function showToast(msg: string, type: 'ok' | 'err') {
    setToast({ msg, type })
    setTimeout(() => setToast(null), 2800)
  }

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <Loader2 size={24} className="animate-spin text-zinc-400" />
    </div>
  )

  const g = goals()
  const isToday = currentDate === todayISO()

  return (
    <div className="page">

      {/* Parcours guidé : premier repas */}
      {obStep === 'journal' && (
        <OnboardingCoach
          mode="nutrition"
          title="Ton premier repas"
          message="Ajoute un repas comme tu veux : à la voix, en photo de ton assiette, ou en texte. Waty détecte les aliments et calcule calories, macros ET micronutriments — le tout comparé à TES objectifs personnalisés (issus de ton profil)."
          onSkip={obSkip}
        />
      )}

      {/* Toast */}
      {toast && (
        <div className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-2.5 rounded-full text-sm font-semibold text-white shadow-lg transition-all ${toast.type === 'ok' ? 'bg-nutri' : 'bg-red-500'}`}>
          {toast.msg}
        </div>
      )}

      {/* Modal ajout */}
      {/* Modal détail nutriment */}
      {nutriModal && (
        <NutrientDetailModal
          title={nutriModal.title}
          color={nutriModal.color}
          entries={nutriModal.entries}
          onClose={() => setNutriModal(null)}
        />
      )}

      {selectedFood && (
        <AddFoodModal food={selectedFood} onConfirm={confirmAdd} onClose={() => setSelectedFood(null)} />
      )}

      {editingEntry && (
        <EditQtyModal entry={editingEntry} onConfirm={qty => updateEntryQty(editingEntry, qty)} onClose={() => setEditingEntry(null)} />
      )}

      {/* Sélecteur de jours : 7 derniers jours, point = journée renseignée */}
      <div className="flex items-center justify-between">
        <p className="text-sm font-extrabold t-text capitalize">{isToday ? "Aujourd'hui" : formatDateFR(currentDate)}</p>
        {!isToday && <button onClick={() => setCurrentDate(todayISO())} className="text-xs font-bold text-tta-mid">Revenir à aujourd'hui</button>}
      </div>
      <div className="grid grid-cols-7 gap-1.5 -mt-1">
        {Array.from({ length: 7 }, (_, i) => {
          const d = addDays(todayISO(), -(6 - i))
          const sel = d === currentDate
          const has = (weekCal[d] ?? 0) > 0
          const over = (weekCal[d] ?? 0) > (g.cal || 2000)
          return (
            <button key={d} onClick={() => setCurrentDate(d)}
              className={`rounded-2xl py-2 flex flex-col items-center gap-0.5 transition-all ${sel ? 'text-white shadow-[0_8px_20px_rgba(34,197,94,0.35)]' : 'bg-transparent'}`}
              style={sel ? { background: 'linear-gradient(135deg,#22C55E,#16A34A)' } : undefined}>
              <span className={`text-[11px] font-bold ${sel ? 'text-white/80' : 't-muted'}`}>{format(new Date(d + 'T12:00'), 'EEEEE', { locale: fr }).toUpperCase()}</span>
              <span className={`text-sm font-extrabold ${sel ? 'text-white' : 't-text'}`}>{format(new Date(d + 'T12:00'), 'd')}</span>
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: has ? (sel ? '#fff' : over ? '#FBBF24' : '#22C55E') : 'transparent' }} />
            </button>
          )
        })}
      </div>

      {/* Résumé du jour : calories + barre empilée + 3 macros (tap = détail par aliment) */}
      {(() => {
        const rest = Math.max(0, Math.round((g.cal || 0) - totals.cal))
        const pct = (v: number, goal: number) => goal > 0 ? Math.min(100, Math.round(v / goal * 100)) : 0
        const barP = g.cal ? Math.min(100, totals.prot * 4 / g.cal * 100) : 0
        const barC = g.cal ? Math.min(100 - barP, totals.carb * 4 / g.cal * 100) : 0
        const barF = g.cal ? Math.min(100 - barP - barC, totals.fat * 9 / g.cal * 100) : 0
        const macros = [
          { label: 'Prot.', val: totals.prot, goal: g.prot, color: '#4B47A0', title: 'Protéines par aliment', key: 'prot' as const },
          { label: 'Gluc.', val: totals.carb, goal: g.carb, color: '#0E7490', title: 'Glucides par aliment',  key: 'carb' as const },
          { label: 'Lip.',  val: totals.fat,  goal: g.fat,  color: '#EA580C', title: 'Lipides par aliment',   key: 'fat'  as const },
        ]
        return (
          <div className="card-hero flex flex-col gap-3 relative overflow-hidden">
            <div className="absolute -top-16 -right-16 w-44 h-44 rounded-full pointer-events-none" style={{ background: 'radial-gradient(closest-side, rgba(34,197,94,0.22), transparent)' }} />
            <button onClick={() => setNutriModal({ title: 'Calories par aliment', color: '#f97316',
                entries: foodEntries.map(e => ({ food_name: e.food_name, value: Number(e.cal), unit: 'kcal' })) })}
              className="text-left">
              <div className="flex items-baseline justify-between">
                <span className="text-xs font-extrabold text-nutri-dark uppercase tracking-wide">Consommé</span>
                <span className="text-xs font-bold t-muted">objectif {g.cal.toLocaleString('fr-FR')}</span>
              </div>
              <div className="flex items-baseline gap-2 mt-0.5">
                <span className="text-[34px] font-extrabold tracking-tight leading-none tabular-nums" style={{ color: '#15803D' }}>{Math.round(totals.cal).toLocaleString('fr-FR')}</span>
                <span className="text-sm font-bold t-muted">kcal · {rest > 0 ? `reste ${rest.toLocaleString('fr-FR')}` : 'objectif atteint'}</span>
              </div>
            </button>
            <div className="h-2.5 rounded-full overflow-hidden flex" style={{ background: 'rgba(34,197,94,0.12)' }}>
              <div className="h-full" style={{ width: `${barP}%`, background: '#4B47A0' }} />
              <div className="h-full" style={{ width: `${barC}%`, background: '#06B6D4' }} />
              <div className="h-full" style={{ width: `${barF}%`, background: '#F97316' }} />
            </div>
            <div className="grid grid-cols-3 gap-2">
              {macros.map(m => (
                <button key={m.key} onClick={() => setNutriModal({ title: m.title, color: m.color,
                    entries: foodEntries.map(e => ({ food_name: e.food_name, value: Number(e[m.key]), unit: 'g' })).filter(e => e.value > 0) })}
                  className="rounded-2xl px-2 py-2.5 text-center active:scale-[0.97] transition-transform" style={{ background: `${m.color}14` }}>
                  <p className="text-[15px] font-extrabold tabular-nums" style={{ color: m.color }}>{Math.round(m.val)} g</p>
                  <p className="text-[11px] font-bold t-muted">{m.label} · {pct(m.val, m.goal)} %</p>
                </button>
              ))}
            </div>
          </div>
        )
      })()}

      {/* Waty conseil nutrition */}
      {(() => {
        const { message, mode } = getWatyMessage({
          type: 'journal',
          calToday: totals.cal,
          calTarget: g.cal,
          protToday: totals.prot,
          protTarget: g.prot,
          isEmpty: entries.length === 0,
        })
        return <Waty mode={mode} message={message} size="sm" />
      })()}

      {/* Modal ajout vocal repas */}
      {showVoiceMeal && (
        <VoiceMeal
          onConfirm={handleVoiceMealConfirm}
          onCancel={() => setShowVoiceMeal(false)}
        />
      )}

      {/* Input photo caché */}
      <input
        ref={photoInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={handlePhotoCapture}
      />

      {/* Modal confirmation photo */}
      {(photoFoods || photoAnalyzing) && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-0 sm:p-4">
          <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="sticky top-0 bg-white px-5 py-4 border-b border-zinc-100 flex items-center justify-between rounded-t-3xl sm:rounded-t-3xl">
              <h3 className="font-extrabold text-zinc-900 inline-flex items-center gap-1.5"><Camera size={15} className="text-tta-mid" /> Analyse de la photo</h3>
              <button onClick={() => { setPhotoFoods(null); setPhotoPreview(null); setPhotoAnalyzing(false) }}
                className="w-8 h-8 rounded-xl bg-zinc-100 flex items-center justify-center text-zinc-400">
                <X size={14} />
              </button>
            </div>
            <div className="p-5 flex flex-col gap-4">
              {/* Preview photo */}
              {photoPreview && (
                <div className="rounded-2xl overflow-hidden border border-zinc-100 max-h-48">
                  <img src={photoPreview} alt="Photo repas" className="w-full h-48 object-cover" />
                </div>
              )}

              {photoAnalyzing && (
                <div className="flex flex-col items-center gap-3 py-6">
                  <Loader2 size={28} className="animate-spin text-nutri" />
                  <p className="text-sm text-zinc-500">L'IA analyse votre repas…</p>
                </div>
              )}

              {photoFoods && !photoAnalyzing && (
                <>
                  <p className="text-xs text-zinc-500">{photoFoods.length} aliment{photoFoods.length > 1 ? 's' : ''} détecté{photoFoods.length > 1 ? 's' : ''}. Modifiez si nécessaire.</p>
                  <div className="flex flex-col gap-2">
                    {photoFoods.map((f, i) => (
                      <div key={i} className="flex items-center gap-3 bg-zinc-50 rounded-2xl px-3 py-2.5">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-zinc-900 truncate">{f.name}</p>
                          <p className="text-xs text-zinc-400">{f.quantity}g · {Math.round(f.cal)} kcal · P:{round1(f.prot)}g · G:{round1(f.carb)}g · L:{round1(f.fat)}g</p>
                        </div>
                        <button onClick={() => setPhotoFoods(prev => prev ? prev.filter((_, j) => j !== i) : null)}
                          className="p-1.5 rounded-lg hover:bg-red-100 text-zinc-300 hover:text-red-500 transition-colors flex-shrink-0">
                          <Trash2 size={13} />
                        </button>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2 pt-1">
                    <button onClick={() => { setPhotoFoods(null); setPhotoPreview(null) }}
                      className="flex-1 py-2.5 rounded-xl border border-zinc-200 text-sm font-medium text-zinc-600 hover:bg-zinc-50">
                      Annuler
                    </button>
                    <button
                      onClick={async () => {
                        if (!photoFoods) return
                        await handleVoiceMealConfirm(photoFoods)
                        setPhotoFoods(null)
                        if (photoPreview) URL.revokeObjectURL(photoPreview)
                        setPhotoPreview(null)
                      }}
                      className="flex-1 py-2.5 rounded-xl bg-nutri text-white text-sm font-bold hover:bg-nutri-dark">
                      <Check size={15} /> Ajouter au journal
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Toast erreur photo */}
      {photoError && !photoAnalyzing && (
        <div className="bg-red-50 border border-red-200 rounded-2xl px-4 py-3 flex items-center gap-2">
          <AlertTriangle size={14} className="flex-shrink-0 mt-0.5 text-red-500" />
          <p className="text-xs text-red-700 flex-1">{photoError}</p>
          <button onClick={() => setPhotoError('')} className="text-red-300 hover:text-red-500"><X size={14} /></button>
        </div>
      )}

      {/* ── Ajouter : trois bulles (vocal/texte · photo · compléments) ── */}
      {!showVoiceMeal && (
        <div className="grid grid-cols-3 gap-3 py-1">
          {[
            { key: 'voice', label: 'Vocal ou texte', sub: 'Dis ce que tu as mangé', art: 'micro' as const, active: false, busy: false, tint: 'rgba(34,197,94,0.14)', ring: 'rgba(34,197,94,0.35)',
              onClick: () => setShowVoiceMeal(true) },
            { key: 'photo', label: 'Photo du repas', sub: 'Waty lit ton assiette', art: 'photo' as const, active: false, busy: photoAnalyzing, tint: 'rgba(37,99,235,0.12)', ring: 'rgba(37,99,235,0.3)',
              onClick: () => photoInputRef.current?.click() },
            { key: 'suppl', label: 'Compléments', sub: supplEntries.length > 0 ? `${supplEntries.length} aujourd'hui` : 'Vitamines, plantes…', art: 'gelules' as const, active: showSupplPanel, busy: false, tint: 'rgba(168,85,247,0.14)', ring: 'rgba(168,85,247,0.35)',
              onClick: () => { setShowSupplPanel(v => !v); setSupplQuery(''); setSupplResults([]) } },
          ].map(b => (
            <button key={b.key} onClick={b.onClick} disabled={b.busy}
              className="flex flex-col items-center gap-2 active:scale-95 transition-transform disabled:opacity-60">
              <span className="relative w-[84px] h-[84px] rounded-full flex items-center justify-center transition-all"
                style={{
                  background: `linear-gradient(160deg, rgba(255,255,255,0.85), ${b.tint})`,
                  border: `1.5px solid ${b.active ? b.ring : 'rgba(255,255,255,0.9)'}`,
                  boxShadow: b.active ? `0 12px 30px ${b.ring}` : `0 10px 28px ${b.tint}`,
                  backdropFilter: 'blur(14px)', WebkitBackdropFilter: 'blur(14px)',
                }}>
                {b.busy
                  ? <span className="w-8 h-8 border-4 border-sky-200 border-t-sky-500 rounded-full animate-spin" />
                  : <MytaIllustration name={b.art} size={46} />}
                {b.key === 'suppl' && supplEntries.length > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 min-w-[22px] h-[22px] px-1.5 rounded-full bg-violet-600 text-white text-[11px] font-extrabold flex items-center justify-center ring-2 ring-white">{supplEntries.length}</span>
                )}
              </span>
              <span className="text-center leading-tight">
                <span className="block text-[12px] font-extrabold t-text">{b.label}</span>
                <span className="block text-[10px] font-semibold t-muted mt-0.5">{b.sub}</span>
              </span>
            </button>
          ))}
        </div>
      )}

      {/* ── Compléments alimentaires (panneau) ── */}
      <div>

        {showSupplPanel && (
          <div className="mt-2 bg-white border border-violet-100 rounded-2xl overflow-hidden shadow-sm">
            {/* Recherche */}
            <div className="p-3 border-b border-zinc-100">
              <div className="relative">
                <input
                  value={supplQuery}
                  onChange={e => handleSupplSearch(e.target.value)}
                  placeholder="Rechercher un complément…"
                  className="w-full pl-9 pr-9 py-2 rounded-xl border border-zinc-200 text-sm focus:outline-none focus:ring-2 focus:ring-violet-300"
                />
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
                {supplQuery && (
                  <button onClick={() => { setSupplQuery(''); setSupplResults([]) }}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-300 hover:text-zinc-500">
                    <X size={14} />
                  </button>
                )}
              </div>
            </div>

            {/* Résultats de recherche */}
            {supplResults.length > 0 && (
              <div className="divide-y divide-zinc-50 max-h-64 overflow-y-auto">
                {supplResults.map(s => (
                  <div key={s.id} className="flex items-center gap-3 px-4 py-3 hover:bg-violet-50/50 transition-colors">
                    <MytaIcon name="pill" size={18} className="text-violet-500 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-zinc-900 truncate">{s.name}</p>
                      <p className="text-xs text-zinc-400 truncate">{s.dose}</p>
                      {s.antiInflam === true && (
                        <span className="text-[10px] text-green-600 font-semibold inline-flex items-center gap-1"><Check size={11} /> Anti-inflammatoire</span>
                      )}
                    </div>
                    <button
                      onClick={() => addSupplement(s)}
                      disabled={addingSuppl}
                      className="flex-shrink-0 bg-violet-100 hover:bg-violet-200 text-violet-700 text-xs font-bold px-3 py-1.5 rounded-xl transition-colors disabled:opacity-50"
                    >
                      + Ajouter
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Parcourir par catégorie */}
            {!supplQuery && (
              <div className="p-3">
                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wide mb-2">Populaires</p>
                <div className="grid grid-cols-2 gap-2">
                  {SUPPLEMENTS.filter(s => ['moringa','spiruline','curcuma','magnesium','vitamine-d','omega3'].includes(s.id)).map(s => (
                    <button
                      key={s.id}
                      onClick={() => addSupplement(s)}
                      disabled={addingSuppl}
                      className="flex items-center gap-2 p-2.5 rounded-xl border border-zinc-100 hover:border-violet-200 hover:bg-violet-50/50 transition-all text-left disabled:opacity-50"
                    >
                      <MytaIcon name="pill" size={16} className="text-violet-500 flex-shrink-0" />
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-zinc-800 truncate">{s.name}</p>
                        {s.antiInflam === true && <p className="text-[9px] text-green-600">Anti-inflam.</p>}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Compléments ajoutés aujourd'hui */}
            {supplEntries.length > 0 && (
              <div className="border-t border-zinc-100 p-3">
                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wide mb-2">Pris aujourd'hui</p>
                <div className="flex flex-col gap-1.5">
                  {supplEntries.map(e => {
                    const def = SUPPLEMENTS.find(s => s.id === (e.food_id ?? '').replace('supp-', ''))
                    return (
                      <div key={e.id} className="flex items-center gap-2 bg-violet-50 rounded-xl px-3 py-2">
                        <MytaIcon name="pill" size={14} className="text-violet-500 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-violet-900 truncate">{e.food_name}</p>
                          {def?.antiInflam === true && <p className="text-[9px] text-green-600">Anti-inflammatoire</p>}
                        </div>
                        <button onClick={() => deleteEntry(e.id)} className="p-1 rounded-lg hover:bg-red-100 text-violet-300 hover:text-red-500 transition-colors">
                          <Trash2 size={12} />
                        </button>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ── Aliments récents — accès rapide ── */}
      {recentFoods.length > 0 && !query && (
        <div className="flex flex-col gap-2">
          <p className="text-xs font-extrabold text-nutri-dark uppercase tracking-wide">Récents</p>
          <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
            {recentFoods.map((food, i) => (
              <button
                key={i}
                onClick={() => setSelectedFood({
                  id: food.food_id ?? food.food_name,
                  name: food.food_name,
                  cal: Number(food.cal),
                  prot: Number(food.prot),
                  carb: Number(food.carb),
                  fat: Number(food.fat),
                  image_url: food.image_url ?? null,
                  cat: food.food_cat ?? '',
                })}
                className="flex-shrink-0 flex flex-col items-center gap-1 bg-white border border-zinc-100 rounded-2xl p-2.5 shadow-sm hover:border-nutri/40 hover:shadow-md transition-all active:scale-95 w-20"
              >
                <div className="w-10 h-10 rounded-xl bg-nutri-light flex items-center justify-center flex-shrink-0 overflow-hidden">
                  {food.image_url
                    ? <img src={food.image_url} alt="" className="w-full h-full object-cover rounded-xl" />
                    : <MytaIllustration name="repas" size={30} />}
                </div>
                <p className="text-[10px] font-semibold text-zinc-700 text-center leading-tight line-clamp-2 w-full">{food.food_name}</p>
                <p className="text-[9px] text-orange-400 font-bold">{Math.round(Number(food.cal))} kcal</p>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Recherche inline via aliments récents ou voix */}

      {/* Journal du jour */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-extrabold t-text">Journal du jour</h2>
          <span className="text-xs text-zinc-400">{foodEntries.length} aliment{foodEntries.length > 1 ? 's' : ''}</span>
        </div>

        {foodEntries.length === 0 ? (
          <div className="card text-center py-8 flex flex-col items-center gap-2">
            <MytaIllustration name="vide" size={56} />
            <p className="text-sm font-bold t-text">Rien de noté pour cette journée.</p>
            <p className="text-xs t-muted">Dicte ton repas, prends-le en photo ou choisis un aliment récent.</p>
          </div>
        ) : (
          <div className="card divide-y divide-zinc-100 p-0">
            {foodEntries.map(e => (
              <div key={e.id} className="flex items-center gap-3 px-4 py-3 hover:bg-zinc-50/50 transition-colors">
                <div className="w-9 h-9 rounded-xl bg-nutri-light flex items-center justify-center flex-shrink-0 overflow-hidden">
                  {e.image_url
                    ? <img src={e.image_url} alt="" className="w-full h-full object-cover rounded-xl" onError={ev => { (ev.target as HTMLImageElement).style.display = 'none' }} />
                    : <MytaIllustration name="repas" size={28} />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">{e.food_name}</p>
                  <p className="text-xs text-zinc-400">{e.quantity}g · P:{e.prot}g · G:{e.carb}g · L:{e.fat}g</p>
                </div>
                <span className="text-sm font-bold text-orange-500 flex-shrink-0">{e.cal} kcal</span>
                <button onClick={() => setEditingEntry(e)} className="p-1.5 rounded-lg hover:bg-blue-50 text-zinc-300 hover:text-blue-500 transition-colors">
                  <Pencil size={14} />
                </button>
                <button onClick={() => deleteEntry(e.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-zinc-300 hover:text-red-500 transition-colors">
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
            <div className="flex items-center justify-between px-4 py-2.5 bg-zinc-50/50">
              <span className="text-xs text-zinc-400 font-medium">{foodEntries.length} aliment{foodEntries.length > 1 ? 's' : ''}</span>
              <span className="text-sm font-bold text-zinc-900">Total : <span className="text-nutri-dark">{totals.cal} kcal</span></span>
            </div>
          </div>
        )}
      </div>

      {/* ── Inflammation & Gluten ── */}
      {foodEntries.length > 0 && (() => {
        const s = calcInflamScore(foodEntries)
        if (!s) return null
        const pct = inflamGaugePct(s.score, s.total)
        const adv = inflamAdvice(s)
        const glutenItems = foodEntries.filter(e => hasGluten(e.food_name))
        return (
          <div className="card flex flex-col gap-3">
            <h3 className="text-sm font-semibold text-zinc-700 inline-flex items-center gap-2"><Flame size={14} className="text-orange-500" /> Inflammation &amp; gluten du jour</h3>

            {/* Jauge */}
            <div>
              <div className="flex justify-between text-[10px] text-zinc-400 mb-1">
                <span>Très inflammatoire</span><span>Anti-inflammatoire</span>
              </div>
              <div className="relative h-3 rounded-full overflow-visible" style={{ background: 'linear-gradient(to right, #ef4444 0%, #f97316 25%, #fbbf24 50%, #86efac 72%, #22c55e 100%)' }}>
                <div className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white border-2 border-zinc-400 rounded-full shadow -translate-x-1/2 transition-all duration-500"
                  style={{ left: `${pct}%` }} />
              </div>
            </div>

            {/* Résumé — badges cliquables */}
            <div className="flex flex-wrap gap-2 text-xs">
              {s.veryInflam > 0 && (
                <button onClick={() => setNutriModal({ title: 'Aliments très inflammatoires', color: '#ef4444',
                  entries: foodEntries.filter(e => classifyInflam(e.food_name) === -2).map(e => ({ food_name: e.food_name, value: Number(e.cal), unit: 'kcal' })) })}
                  className="px-2 py-0.5 rounded-full bg-red-100 text-red-700 font-medium hover:bg-red-200 transition-colors">
                  <Circle size={9} fill="#ef4444" strokeWidth={0} /> {s.veryInflam} très inflam.
                </button>
              )}
              {s.inflam > 0 && (
                <button onClick={() => setNutriModal({ title: 'Aliments inflammatoires', color: '#f97316',
                  entries: foodEntries.filter(e => classifyInflam(e.food_name) === -1).map(e => ({ food_name: e.food_name, value: Number(e.cal), unit: 'kcal' })) })}
                  className="px-2 py-0.5 rounded-full bg-orange-100 text-orange-700 font-medium hover:bg-orange-200 transition-colors">
                  <Circle size={9} fill="#f97316" strokeWidth={0} /> {s.inflam} inflammatoire{s.inflam > 1 ? 's' : ''}
                </button>
              )}
              {s.anti > 0 && (
                <button onClick={() => setNutriModal({ title: 'Aliments anti-inflammatoires', color: '#22c55e',
                  entries: foodEntries.filter(e => classifyInflam(e.food_name) === 1).map(e => ({ food_name: e.food_name, value: Number(e.cal), unit: 'kcal' })) })}
                  className="px-2 py-0.5 rounded-full bg-nutri-light text-nutri-dark font-medium hover:bg-nutri/20 transition-colors">
                  <Circle size={9} fill="#22c55e" strokeWidth={0} /> {s.anti} anti-inflam.
                </button>
              )}
              {s.neutral > 0 && (
                <button onClick={() => setNutriModal({ title: 'Aliments neutres', color: '#71717a',
                  entries: foodEntries.filter(e => classifyInflam(e.food_name) === 0).map(e => ({ food_name: e.food_name, value: Number(e.cal), unit: 'kcal' })) })}
                  className="px-2 py-0.5 rounded-full bg-zinc-100 text-zinc-500 font-medium hover:bg-zinc-200 transition-colors">
                  <Circle size={9} fill="#a1a1aa" strokeWidth={0} /> {s.neutral} neutre{s.neutral > 1 ? 's' : ''}
                </button>
              )}
              {/* Compléments anti-inflam du jour */}
              {supplEntries.filter(e => {
                const def = SUPPLEMENTS.find(s => s.id === (e.food_id ?? '').replace('supp-', ''))
                return def?.antiInflam === true
              }).length > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-violet-100 text-violet-700 font-medium">
                  <Pill size={12} className="inline" /> {supplEntries.filter(e => {
                    const def = SUPPLEMENTS.find(s => s.id === (e.food_id ?? '').replace('supp-', ''))
                    return def?.antiInflam === true
                  }).length} complément{supplEntries.length > 1 ? 's' : ''} anti-inflam.
                </span>
              )}
            </div>

            {/* Conseil */}
            <div className={`rounded-xl p-3 border text-xs leading-relaxed ${adv.cls}`}>
              {adv.text}
            </div>

            {/* Gluten */}
            {glutenItems.length > 0 && (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
                <p className="text-xs font-semibold text-amber-700 mb-1.5 inline-flex items-center gap-1.5"><Wheat size={13} /> Aliments contenant du gluten</p>
                <div className="flex flex-wrap gap-1.5">
                  {glutenItems.map(e => (
                    <span key={e.id} className="text-[10px] px-2 py-0.5 bg-amber-100 text-amber-800 rounded-full">{e.food_name}</span>
                  ))}
                </div>
              </div>
            )}

            <p className="text-[10px] text-zinc-400 italic">Indicateur informatif — ne remplace pas un avis médical.</p>
          </div>
        )
      })()}

      {/* ── Micronutriments (barres fusionnées aliments + compléments) ── */}
      {(foodEntries.length > 0 || supplEntries.length > 0) && (() => {
        const micros = calcMicros(foodEntries.map(e => ({ food_id: e.food_id ?? '', food_name: e.food_name, quantity: e.quantity })))

        // Compléments
        const supplDefs = supplEntries
          .map(e => {
            const def = SUPPLEMENTS.find(s => s.id === (e.food_id ?? '').replace('supp-', ''))
            return def ? { supplement: def, qty: e.quantity ?? 1 } : null
          })
          .filter(Boolean) as { supplement: Supplement; qty: number }[]
        const supplMicros = calcSupplementMicros(supplDefs)

        // Micros aliments qui ont des données
        const withData = micros.filter(m => m.hasData)

        // Micros supplément-only (vitE, curcumin, polyphenols) — pas couverts par CIQUAL
        const suppOnlyKeys: MicroKey[] = ['vitE', 'curcumin', 'polyphenols']
        const suppOnlyRows = suppOnlyKeys
          .map(k => ({ key: k, val: supplMicros[k] ?? 0, def: MICRO_RDA[k] }))
          .filter(r => r.val > 0)

        const hasAnything = withData.length > 0 || suppOnlyRows.length > 0

        if (!hasAnything) return (
          <div className="card">
            <h3 className="text-sm font-semibold text-zinc-700 mb-2 inline-flex items-center gap-2"><Microscope size={14} className="text-tta-mid" /> Micronutriments du jour</h3>
            <p className="text-xs text-zinc-400">Données insuffisantes — ajoutez des aliments CIQUAL ou des compléments pour visualiser vos apports.</p>
          </div>
        )

        const hasSuppContrib = Object.keys(supplMicros).length > 0

        return (
          <div className="card flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-zinc-700 inline-flex items-center gap-2"><Microscope size={14} className="text-tta-mid" /> Micronutriments du jour</h3>
              <div className="flex items-center gap-2 text-[10px] text-zinc-400">
                {hasSuppContrib && <span className="flex items-center gap-0.5"><span className="inline-block w-2 h-2 rounded-full bg-violet-400" /> Compléments</span>}
                <span>% AJR</span>
              </div>
            </div>

            {/* ── Barres fusionnées CIQUAL + compléments ── */}
            {withData.length > 0 && (
              <div className="grid grid-cols-1 gap-2">
                {micros.map(m => {
                  const suppKey = MICRO_NAME_TO_SUPP_KEY[m.name]
                  const suppVal = suppKey ? (supplMicros[suppKey] ?? 0) : 0
                  const suppPct = suppVal > 0 && m.ajr > 0 ? Math.round((suppVal / m.ajr) * 100) : 0
                  const foodPct = Math.min(m.pct, 100)
                  const totalPct = Math.min(150, (m.hasData ? m.pct : 0) + suppPct)

                  return (
                    <button key={m.name} onClick={() => {
                      if (!m.hasData && !suppPct) return
                      setNutriModal({
                        title: `${m.name} — aliments du jour`,
                        color: m.color,
                        entries: foodEntries.map(e => ({ food_name: e.food_name, value: Number(e.cal), unit: 'kcal' })).filter(e => e.value > 0),
                      })
                    }}
                      className={`flex items-center gap-2 text-left rounded-xl p-1.5 transition-colors ${(m.hasData || suppPct > 0) ? 'hover:bg-zinc-50 cursor-pointer' : 'cursor-default'}`}>
                      <span className="text-xs text-zinc-500 w-20 flex-shrink-0">{m.name}</span>
                      {(m.hasData || suppPct > 0) ? (
                        <>
                          {/* Barre fusionnée : aliments (couleur) + complément (violet, empilé) */}
                          <div className="flex-1 h-1.5 bg-zinc-100 rounded-full overflow-hidden relative">
                            {m.hasData && (
                              <div className="absolute inset-y-0 left-0 rounded-full transition-all duration-500"
                                style={{ width: `${foodPct}%`, background: m.color }} />
                            )}
                            {suppPct > 0 && (
                              <div className="absolute inset-y-0 rounded-full transition-all duration-500"
                                style={{
                                  left: `${m.hasData ? foodPct : 0}%`,
                                  width: `${Math.min(suppPct, 100 - (m.hasData ? foodPct : 0))}%`,
                                  background: '#8b5cf6',
                                  opacity: 0.85,
                                }} />
                            )}
                          </div>
                          <span className="text-xs font-bold w-10 text-right flex-shrink-0"
                            style={{ color: totalPct >= 100 ? '#22c55e' : (m.hasData ? m.color : '#8b5cf6') }}>
                            {totalPct > 999 ? '>999%' : `${totalPct}%`}
                          </span>
                        </>
                      ) : (
                        <span className="text-[10px] text-zinc-300 italic flex-1">données insuffisantes</span>
                      )}
                    </button>
                  )
                })}
              </div>
            )}

            {/* ── Micros supplément-only (vitE, curcumine, polyphénols) ── */}
            {suppOnlyRows.length > 0 && (
              <div className={withData.length > 0 ? 'border-t border-zinc-100 pt-3' : ''}>
                {withData.length > 0 && (
                  <p className="text-[10px] font-bold text-violet-500 uppercase tracking-wide mb-2 inline-flex items-center gap-1.5"><Pill size={12} /> Compléments uniquement</p>
                )}
                <div className="grid grid-cols-1 gap-2">
                  {suppOnlyRows.map(({ key, val, def }) => {
                    const pct = Math.min(150, Math.round((val / def.rda) * 100))
                    return (
                      <div key={key} className="flex items-center gap-2">
                        <span className="text-xs text-zinc-500 w-20 flex-shrink-0">{def.label}</span>
                        <div className="flex-1 h-1.5 bg-zinc-100 rounded-full overflow-hidden">
                          <div className="h-full rounded-full transition-all duration-500"
                            style={{ width: `${Math.min(pct, 100)}%`, background: '#8b5cf6' }} />
                        </div>
                        <span className="text-xs font-bold w-10 text-right flex-shrink-0" style={{ color: '#8b5cf6' }}>
                          {pct > 999 ? '>999%' : `${pct}%`}
                        </span>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {/* Compléments du jour en badges */}
            {supplDefs.length > 0 && (
              <div className="bg-violet-50 rounded-xl px-3 py-2.5">
                <p className="text-[10px] font-semibold text-violet-700 mb-1 inline-flex items-center gap-1.5"><Pill size={12} /> Compléments du jour</p>
                <div className="flex flex-wrap gap-1">
                  {supplDefs.map(({ supplement }) => (
                    <span key={supplement.id} className="text-[10px] bg-white border border-violet-200 text-violet-700 px-2 py-0.5 rounded-full">
                      {supplement.name}
                      {supplement.antiInflam === true && ' — anti-inflammatoire'}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <p className="text-[10px] text-zinc-400 italic">Indicateur informatif — ne remplace pas un avis médical.</p>
          </div>
        )
      })()}

      {/* ── Tracker tabac ── */}
      {(profile as any)?.smoking_goal && (
        <div className="card flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h2 className="font-extrabold text-zinc-900 text-sm flex items-center gap-1.5">
              <span className="inline-flex items-center gap-1.5"><Cigarette size={14} /> Suivi tabac</span>
            </h2>
            {smokingStreak > 0 && (
              <span className="text-[10px] font-bold bg-green-100 text-green-700 px-2 py-1 rounded-full">
                <span className="inline-flex items-center gap-1.5"><Trophy size={12} /> {smokingStreak}j à 0 cig.</span>
              </span>
            )}
          </div>

          {/* Compteur */}
          <div className="flex items-center justify-between bg-zinc-50 rounded-2xl px-5 py-4">
            <div className="text-center">
              <p className="text-4xl font-black text-zinc-900">{smokingCount}</p>
              <p className="text-xs text-zinc-400 mt-1">
                cigarette{smokingCount > 1 ? 's' : ''} aujourd'hui
              </p>
              {smokingYesterday !== null && (
                <p className={`text-[10px] mt-1 font-semibold ${
                  smokingCount < smokingYesterday ? 'text-green-600'
                  : smokingCount > smokingYesterday ? 'text-orange-500'
                  : 'text-zinc-400'
                }`}>
                  {smokingCount < smokingYesterday ? `↓ ${smokingYesterday - smokingCount} de moins qu'hier`
                  : smokingCount > smokingYesterday ? `↑ ${smokingCount - smokingYesterday} de plus qu'hier`
                  : `= pareil qu'hier (${smokingYesterday})`}
                </p>
              )}
            </div>

            <div className="flex flex-col gap-2">
              {/* Bouton rouge principal */}
              <button
                onClick={async () => {
                  if (savingSmoke) return
                  setSavingSmoke(true)
                  const newCount = smokingCount + 1
                  const { data: { user } } = await supabase.auth.getUser()
                  if (user) {
                    await supabase.from('smoking_log').upsert(
                      { user_id: user.id, log_date: todayISO(), count: newCount, updated_at: new Date().toISOString() },
                      { onConflict: 'user_id,log_date' }
                    )
                  }
                  setSmokingCount(newCount)
                  setSavingSmoke(false)
                }}
                disabled={savingSmoke}
                className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600 active:scale-95 text-white text-2xl font-black shadow-lg transition-all flex items-center justify-center"
              >
                {savingSmoke ? <Loader2 size={20} className="animate-spin" /> : '+1'}
              </button>

              {/* Retour arrière si erreur */}
              {smokingCount > 0 && (
                <button
                  onClick={async () => {
                    if (savingSmoke) return
                    setSavingSmoke(true)
                    const newCount = Math.max(0, smokingCount - 1)
                    const { data: { user } } = await supabase.auth.getUser()
                    if (user) {
                      await supabase.from('smoking_log').upsert(
                        { user_id: user.id, log_date: todayISO(), count: newCount, updated_at: new Date().toISOString() },
                        { onConflict: 'user_id,log_date' }
                      )
                    }
                    setSmokingCount(newCount)
                    setSavingSmoke(false)
                  }}
                  className="text-[10px] text-zinc-400 hover:text-zinc-600 text-center"
                >
                  ↩ Annuler
                </button>
              )}
            </div>
          </div>

          {/* Message Waty */}
          <div className="bg-blue-50 rounded-2xl px-4 py-3 flex items-start gap-2">
            <Heart size={14} className="flex-shrink-0 mt-0.5 text-tta-mid" />
            <p className="text-xs text-blue-700 leading-relaxed">
              {getSmokingWatyMessage(smokingCount, smokingYesterday, smokingStreak)}
            </p>
          </div>

          <p className="text-[10px] text-zinc-400 text-center italic">
            Appuie sur le bouton rouge à chaque cigarette fumée.
            Waty ne te juge jamais — il t'encourage toujours.
          </p>
        </div>
      )}

      {/* Deux colonnes : poids + graphique semaine */}
      <div className="grid grid-cols-1 gap-4">

        {/* Poids — masqué pour les profils enfants */}
        {!getActiveProfile().isChild && <div className="card flex flex-col gap-3">
          <h3 className="text-sm font-semibold flex items-center gap-1.5"><Scale size={14} />Poids du jour</h3>
          <div className="flex gap-2">
            <input type="number" step="0.1" min="30" max="300" value={weightInput}
              onChange={e => setWeightInput(e.target.value)}
              placeholder="ex: 72.5" className="input flex-1" />
            <button onClick={logWeight} disabled={savingWeight} className="btn-nutri px-4 py-2 whitespace-nowrap">
              {savingWeight ? <Loader2 size={14} className="animate-spin" /> : 'Enregistrer'}
            </button>
          </div>
          <div className="flex flex-col gap-1 mt-1">
            {weights.slice(0, 5).map((w, i, arr) => {
              const prev = arr[i + 1]
              const diff = prev ? round1(w.weight_kg - prev.weight_kg) : null
              return (
                <div key={w.id} className="flex items-center justify-between text-xs py-1 border-b border-zinc-100 last:border-0">
                  <span className="text-zinc-400">{format(new Date(w.date + 'T12:00'), 'd/MM/yyyy')}</span>
                  <span className="font-bold text-blue-600">
                    {w.weight_kg} kg
                    {diff !== null && diff !== 0 && (
                      <span className={`ml-1.5 text-[10px] ${diff > 0 ? 'text-red-500' : 'text-nutri'}`}>
                        {diff > 0 ? '▲' : '▼'} {Math.abs(diff)}
                      </span>
                    )}
                  </span>
                </div>
              )
            })}
            {weights.length === 0 && <p className="text-xs text-zinc-400">Aucune entrée encore.</p>}
          </div>
        </div>}

        {/* Calories 7 jours — curseurs de progression */}
        <div className="card flex flex-col gap-3">
          <h3 className="text-sm font-semibold flex items-center gap-1.5">
            <BarChart3 size={14} />Calories — 7 derniers jours
          </h3>
          <div className="flex flex-col gap-2.5">
            {Array.from({ length: 7 }, (_, i) => {
              const d        = addDays(todayISO(), -(6 - i))
              const val      = weekCal[d] ?? 0
              const target   = g.cal || 2000
              const pct      = Math.round((val / target) * 100)
              const isT      = d === currentDate
              const over     = val > target
              const dayLabel = format(new Date(d + 'T12:00'), 'EEE d', { locale: fr })
              const barColor = val === 0 ? '#e5e7eb'
                : over        ? '#f97316'
                : pct >= 80   ? '#22c55e'
                : pct >= 50   ? '#84cc16'
                :               '#d1d5db'
              return (
                <div key={d} className={`flex flex-col gap-1 ${isT ? 'opacity-100' : 'opacity-80'}`}>
                  <div className="flex items-center justify-between text-[11px]">
                    <span className={`font-semibold capitalize ${isT ? 'text-zinc-900' : 'text-zinc-500'}`}>
                      {dayLabel}{isT ? " · Aujourd'hui" : ''}
                    </span>
                    <span className={`font-bold ${
                      val === 0 ? 'text-zinc-300'
                      : over    ? 'text-orange-500'
                      : pct >= 80 ? 'text-green-500'
                      : 'text-zinc-500'
                    }`}>
                      {val === 0 ? '—' : `${val} kcal`}
                      {val > 0 && <span className="text-zinc-400 font-normal"> / {target}</span>}
                    </span>
                  </div>
                  <div className="relative h-4 bg-zinc-100 rounded-full overflow-hidden">
                    <div
                      className="absolute inset-y-0 left-0 rounded-full transition-all duration-700"
                      style={{ width: val === 0 ? '0%' : over ? '100%' : `${pct}%`, backgroundColor: barColor }}
                    />
                    {over && (
                      <div className="absolute right-0 inset-y-0 flex items-center pr-2">
                        <span className="text-[9px] font-extrabold text-orange-600">+{pct - 100}%</span>
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
          <div className="flex items-center gap-3 flex-wrap text-[10px] text-zinc-400 pt-1 border-t border-zinc-50">
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500 inline-block"/>Objectif atteint</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-orange-400 inline-block"/>Dépassé</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-zinc-200 inline-block"/>Non noté</span>
          </div>
        </div>
      </div>
    </div>
  )
}
